


export const actionTypes = { 
    create: 'Create', 
    update: 'Update', 
    delete: 'Delete', 
    save: 'Save', 
    load: 'Load', 
}; 